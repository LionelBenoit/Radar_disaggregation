close all
clear all

%*************load data************
%Here data are already formated:
% - Two summers (2017 and 2018) of rain gauge data are available in the following repository: https://zenodo.org/record/3613841#.X1gewtRCeUk
% - Corresponding radar data should be requested to the Swiss federal office of meteorology and climatology (MeteoSwiss)).
% - For rain typing you can use the following utility: https://github.com/LionelBenoit/Rain_typing
% - For radar image pre-processing (shift to improve agreement with rain gauges), please refer to: Yan, J. and B�rdossy, A. (2019). Short time precipitation estimation using weather radar and surface observations: With rainfall displacement information integrated in a stochastic manner, Journal of Hydrology, 574, 672-682, doi:10.1016/j.jhydrol.2019.04.061


%M=load('struct_blocks_raintype1_2types.mat'); %Data for rain type 1 - convective
M=load('struct_blocks_raintype2_2types.mat'); %Data for rain type 2 - stratiform
Data_rain=M.struct_blocks;

%************load stochastic rainfall models***********
%For model parameter inference, you can use the code available in the following github repository : https://github.com/LionelBenoit/Local-rainfall-model. Do not forget to change the model of marginal distribution and covariance to be in agreement with the disaggregation model!!

%----Point-scale model----
%M=load('V_sample_pluvi_raintype1_2types.mat'); %Point-scale model parameters for rain type 1 - convective
M=load('V_sample_pluvi_raintype2_2types.mat'); %Point-scale model parameters for rain type 2 - stratiform
V_sample_raingauges=M.V_sample_pluvi;
m_raingauges=mean(V_sample_raingauges(:,1:12));

%----Block-scale model----
%M=load('V_sample_radar_raintype1_2types.mat'); %Block-scale model parameters for rain type 1 - convective
M=load('V_sample_radar_raintype2_2types.mat'); %Block-scale model parameters for rain type 2 - stratiform
V_sample_radar=M.V_sample_radar;
m_radar=mean(V_sample_radar(:,1:12));

%*********mismatch parameters*********
%To obtain these parameters for a new dataset, first run radar image disaggregation in unconditional model (i.e. uncomment l 115-120 below), and compare with rain gauge observations

%std_mismatch=0.37; %type 1
std_mismatch=0.12; %type 2

%*********Data fusion********
%-----Set fusion parameters-----
pts_per_km=5; %resolution of fusion output
nb_simul=10; %number of realizations
nb_max_cond=4; %number of conditioning time steps in multigrid simulation
output_file='Movie_datafusion_event12.gif'; %name of output file (movie in gif format). Set 'output_file=[];' to disable movie generation.
output_file=[];

%-----Run data fusion-----
for rain_event=12:12% %Data fusion for example event 12 only
%for rain_event=1:length(Data_rain) %Data fusion for all events
    if ~isempty(Data_rain(rain_event).shift_X)
        MeasuredRadar=Data_rain(rain_event).MeasuredRadar;
        MeasuredRainTS=Data_rain(rain_event).MeasuredRainTS;
        my_ind=find(abs(MeasuredRainTS(1).t-MeasuredRadar(1).t(1))<15);
        
        t0=MeasuredRadar(1).t(1);
        for i=1:length(MeasuredRainTS)
            MeasuredRainTS(i).t=MeasuredRainTS(i).t(my_ind:end)-t0;
            MeasuredRainTS(i).t_double=MeasuredRainTS(i).t_double(my_ind:end)-t0;
            MeasuredRainTS(i).t_datetime=MeasuredRainTS(i).t_datetime(my_ind:end);
            MeasuredRainTS(i).RainRate=MeasuredRainTS(i).RainRate(my_ind:end);
        end
        for i=1:length(MeasuredRadar)
            MeasuredRadar(i).t=MeasuredRadar(i).t(:)-t0;
        end
        
        Data_rain(rain_event).MeasuredRainTS=MeasuredRainTS;
        Data_rain(rain_event).MeasuredRadar=MeasuredRadar;
        
        X_radar=[];
        Y_radar=[];
        for i=1:length(MeasuredRadar)
            X_radar=[X_radar; MeasuredRadar(i).X];
            Y_radar=[Y_radar; MeasuredRadar(i).Y];
        end
        min_X_grid=min(X_radar)-500+0.5*1000/pts_per_km;
        max_X_grid=max(X_radar)+500-0.5*1000/pts_per_km;
        min_Y_grid=min(Y_radar)-500+0.5*1000/pts_per_km;
        max_Y_grid=max(Y_radar)+500-0.5*1000/pts_per_km;
        
        
        X_grid=min_X_grid:1000/pts_per_km:max_X_grid;
        Y_grid=min_Y_grid:1000/pts_per_km:max_Y_grid;
        
        Coord_Euler=[];
        for i=1:length(X_grid)
            for j=1:length(Y_grid)
                Coord_Euler=[Coord_Euler;[X_grid(i),Y_grid(j)]];
            end
        end
        
        Condi_RainTS_gaussian=MeasuredRainTS;
        for i=1:length(Condi_RainTS_gaussian)
            
            for j=1:length(Condi_RainTS_gaussian(i).t)
                if Condi_RainTS_gaussian(i).RainRate(j)<0.01
                    Condi_RainTS_gaussian(i).RainRate(j)=m_raingauges(7)-0.1;
                else
                    Condi_RainTS_gaussian(i).RainRate(j)=m_raingauges(7)+(log(Condi_RainTS_gaussian(i).RainRate(j)/m_raingauges(9)+1)/m_raingauges(8))^(1/m_raingauges(12));
                end
            end
            
            Condi_RainTS_gaussian(i).t=Condi_RainTS_gaussian(i).t(2:end);
            Condi_RainTS_gaussian(i).RainRate=Condi_RainTS_gaussian(i).RainRate(2:end);
            
            Data_rain(rain_event).Condi_RainTS_gaussian=Condi_RainTS_gaussian;
        end
        
        CondiRadar=MeasuredRadar;
        
        step_t=Condi_RainTS_gaussian(1).t(2)-Condi_RainTS_gaussian(1).t(1);
        nb_ep=length(Condi_RainTS_gaussian(1).t);
        
        M_SimulatedRainTS=[];
        m=[m_raingauges, m_radar(7:9) m_radar(12) std_mismatch];
        nb_iter_gibbs=50;
        
        
        %-----Activate for unconditional simulation-----
        %{
        m(13)=0.0;
        Condi_RainTS_gaussian=Condi_RainTS_gaussian(1);
        Condi_RainTS_gaussian(1).RainRate=Condi_RainTS_gaussian(1).RainRate*NaN;
        %}
        
        %-----Perform data fusion; results are stored in M_SimulatedRainTS-----
        [M_SimulatedRainTS]=simul_condi_multigrid_withradar(Coord_Euler,pts_per_km,Condi_RainTS_gaussian,CondiRadar,m,nb_ep, step_t,nb_max_cond,nb_iter_gibbs,nb_simul);
        
        %------[optional] Generate movie to visualize data fusion results-----
        if ~isempty(output_file)
            make_fusion_movie(M_SimulatedRainTS,min_X_grid,max_X_grid,min_Y_grid,max_Y_grid,X_grid,Y_grid,pts_per_km,output_file,MeasuredRainTS,MeasuredRadar,CondiRadar);
        end
        
    end
end

