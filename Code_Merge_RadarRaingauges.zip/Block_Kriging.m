function[Lambda_a,Z_est,Var_est]=Block_Kriging(Xa,Ya,Za,Xvmin,Xvstep,Xvmax,Yvmin,Yvstep,Yvmax,m)
%Function for Block Kriging... Caution: only in space!!!
%-----------------------------------------
%input parameters
%Xa,Ya: coordinates of data points
%Za: Observations at data points
%Xvmin,Xvstep,Xvmax,Yvmin,Yvstep,Yvmax: define the target block and its discretization 
%output parameters    
%Lamda_a:kriging weigths
%Z_est: estimated block value
%Var_est: variance of estimation
%----------------------------------------
%build covariance matrix Cab Cav and Cvv
MVX1=repmat(Xa,1,length(Xa));
MVX2=repmat(Xa',length(Xa),1);
MVY1=repmat(Ya,1,length(Ya));
MVY2=repmat(Ya',length(Ya),1);

M_ds=sqrt((MVX2-MVX1).^2+(MVY2-MVY1).^2);


clear MVX1
clear MVX2
clear MVY1
clear MVY2

to=1;
c=m(1)^(-2*m(2));
Elem=1;
Sigma=1./(Elem.^to).*exp(-c.*(M_ds.^(2.*m(2)))./(Elem.^(m(5).*m(2))));
[sx1,~]=size(Sigma);
Cab=(1-m(6)^2)*Sigma+eye(sx1)*(m(6)^2);

Xv=[];
Yv=[];
for i=Xvmin:Xvstep:Xvmax
    for j=Yvmin:Yvstep:Yvmax
        Xv=[Xv;i];
        Yv=[Yv;j];
    end
end


MVX1=repmat(Xa,1,length(Xv));
MVX2=repmat(Xv',length(Xa),1);
MVY1=repmat(Ya,1,length(Yv));
MVY2=repmat(Yv',length(Ya),1);

M_ds=sqrt((MVX2-MVX1).^2+(MVY2-MVY1).^2);

clear MVX1
clear MVX2
clear MVY1
clear MVY2

to=1;
c=m(1)^(-2*m(2));
Elem=1;
Sigma=exp(-c.*(M_ds.^(2.*m(2)))./(Elem.^(m(5).*m(2)))); %no measurement noise

Cav_square=(1-m(6)^2)*Sigma+(M_ds==0)*(m(6)^2);
Cav=mean(Cav_square,2);

%---
MVX1=repmat(Xv,1,length(Xv));
MVX2=repmat(Xv',length(Xv),1);
MVY1=repmat(Yv,1,length(Yv));
MVY2=repmat(Yv',length(Yv),1);

M_ds=sqrt((MVX2-MVX1).^2+(MVY2-MVY1).^2);

clear MVX1
clear MVX2
clear MVY1
clear MVY2

to=1;
c=m(1)^(-2*m(2));
Elem=1;
Sigma=exp(-c.*(M_ds.^(2.*m(2)))./(Elem.^(m(5).*m(2)))); %no measurement noise

Cvv=mean(mean(Sigma));

Lambda_a=inv(Cab)*Cav;
Z_est=Za'*Lambda_a;
Var_est=Cvv-Lambda_a'*Cav;
    
end