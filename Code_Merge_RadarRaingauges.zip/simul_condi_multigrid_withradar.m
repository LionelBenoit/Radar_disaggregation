function[M_SimulatedRainTS]=simul_condi_multigrid_withradar(Coord_Euler,pts_per_km,CondiRainTS_gaussian,CondiRadar,m,nb_ep, step_t,nb_max_cond,nb_iter_gibbs,nb_simul)

%!!CondiRainTS_gaussian.t have to start at 0.
timeline_RainTS=CondiRainTS_gaussian(1).t;
if sum(isnan(CondiRainTS_gaussian(1).RainRate))==length(CondiRainTS_gaussian(1).RainRate)
    CondiRainTS_gaussian=[];
end

M_res_sim=zeros(length(Coord_Euler),nb_ep,nb_simul);

%generate multigrid simulation path
ep_radar=[];
ep_no_radar=[];
for i=1:nb_ep
    ind_path_radar=find(abs(CondiRadar(1).t-i*step_t)<5);
    if ~isempty(ind_path_radar)
        ep_radar=[ep_radar;i];
    else
        ep_no_radar=[ep_no_radar;i];
    end
end
ep_radar
ep_no_radar
%start with epochs with radar data
Path_to_sim=[ep_radar(1);ep_radar(end)]./5;
To_sim=ep_radar(2:end-1)./5;
while ~isempty(To_sim)
    V_path_temp=[];
    sim_path_sort=sort(Path_to_sim);
    for i=2:length(sim_path_sort)
        ind_min=sim_path_sort(i-1)+1;
        ind_max=sim_path_sort(i)-1;
        if ind_min>ind_max
            Path_to_sim=[Path_to_sim;To_sim];
            To_sim=[];
            break;
        end
        bmin=find(To_sim==ind_min);
        bmax=find(To_sim==ind_max);
        temp=floor(median((To_sim(bmin:bmax))));
        rem=find(To_sim==temp);
        To_sim=[To_sim(1:rem-1);To_sim(rem+1:end)];
        V_path_temp=[V_path_temp;temp];
    end
    if ~isempty(V_path_temp)
        Path_to_sim=[Path_to_sim;V_path_temp];
    end
end
%continue with epochs without radar
Path_to_sim=Path_to_sim.*5;
To_sim=ep_no_radar;
while ~isempty(To_sim)
    V_path_temp=[];
    sim_path_sort=sort(Path_to_sim);
    for i=2:length(sim_path_sort)
        
        ind_min=sim_path_sort(i-1)+1;
        ind_max=sim_path_sort(i)-1;
        if ind_min>ind_max
            Path_to_sim=[Path_to_sim;To_sim];
            To_sim=[];
            break;
        end
        bmin=find(To_sim==ind_min);
        bmax=find(To_sim==ind_max);
        temp=floor(median((To_sim(bmin:bmax))));
        rem=find(To_sim==temp);
        To_sim=[To_sim(1:rem-1);To_sim(rem+1:end)];
        V_path_temp=[V_path_temp;temp];
    end
    if ~isempty(V_path_temp)
        Path_to_sim=[Path_to_sim;V_path_temp];
    end
end
    

ind1=find(Path_to_sim==1);
Path_to_sim(ind1)=[];
Path_to_sim=[1;Path_to_sim];

Path_to_sim

Simulated_pts=[];

for i=1:length(Path_to_sim)
    display(strcat('Simulcondi: random path=',num2str(i),'/',num2str(length(Path_to_sim))))
    
    %search conditioning points
    V_dist_t=abs(Simulated_pts-Path_to_sim(i));
    V_dist_tempo_sort=sort(V_dist_t);
    ind_sort=min(nb_max_cond,length(V_dist_t));
    if ind_sort>0
        dist_max=V_dist_tempo_sort(ind_sort);
        %Simulated_pts
        V_ind_cond=find(V_dist_t<=dist_max);%
        pts_condi=[];
        %conditioning to previous simulations
        for j=1:length(V_ind_cond)
            for k=1:length(Coord_Euler(:,1))
                temp=[Coord_Euler(k,1)-Simulated_pts(V_ind_cond(j))*step_t*m(10)*cos(m(11)*pi/180), Coord_Euler(k,2)-Simulated_pts(V_ind_cond(j))*step_t*m(10)*sin(m(11)*pi/180), Simulated_pts(V_ind_cond(j))*step_t];
                pts_condi=[pts_condi; temp];
            end
        end   
        nb_harddata=0;
        for j=1:length(CondiRainTS_gaussian)
          
            my_idx=find((CondiRainTS_gaussian(j).t > (Path_to_sim(i)-10)*step_t) & (CondiRainTS_gaussian(j).t < (Path_to_sim(i)+10)*step_t));
            ind_min=min(my_idx);
            ind_max=max(my_idx);
            
            temp=[CondiRainTS_gaussian(j).X-CondiRainTS_gaussian(j).t(ind_min:ind_max)*m(10)*cos(m(11)*pi/180), CondiRainTS_gaussian(j).Y-CondiRainTS_gaussian(j).t(ind_min:ind_max)*m(10)*sin(m(11)*pi/180), CondiRainTS_gaussian(j).t(ind_min:ind_max)];
            pts_condi=[pts_condi; temp];
            nb_harddata=nb_harddata+length(CondiRainTS_gaussian(j).RainRate(ind_min:ind_max));
            
        end
    else
        pts_condi=[];
        nb_harddata=0;
        for j=1:length(CondiRainTS_gaussian)

            my_idx=find((CondiRainTS_gaussian(j).t > (Path_to_sim(i)-10)*step_t) & (CondiRainTS_gaussian(j).t < (Path_to_sim(i)+10)*step_t));
            ind_min=min(my_idx);
            ind_max=max(my_idx);
            temp=[CondiRainTS_gaussian(j).X-CondiRainTS_gaussian(j).t(ind_min:ind_max)*m(10)*cos(m(11)*pi/180), CondiRainTS_gaussian(j).Y-CondiRainTS_gaussian(j).t(ind_min:ind_max)*m(10)*sin(m(11)*pi/180), CondiRainTS_gaussian(j).t(ind_min:ind_max)];
            pts_condi=[pts_condi; temp];
            nb_harddata=nb_harddata+length(CondiRainTS_gaussian(j).RainRate(ind_min:ind_max));
            
        end
    end
    
    pts_target=[];

    for k=1:length(Coord_Euler(:,1))
        temp=[Coord_Euler(k,1)-Path_to_sim(i)*step_t*m(10)*cos(m(11)*pi/180), Coord_Euler(k,2)-Path_to_sim(i)*step_t*m(10)*sin(m(11)*pi/180), Path_to_sim(i)*step_t];
        pts_target=[pts_target;temp];
    end
    
    if ~isempty(pts_condi)
        my_t=timeline_RainTS(Path_to_sim(i));
        ind_radar=find(abs(CondiRadar(1).t-my_t)<5);
        
        if isempty(ind_radar)
            %covariance matrices
            [Sigma_target]=M_cov_target(pts_target,m);
            [Sigma_condi]=M_cov_obs(pts_condi,nb_harddata,m);
            inv_Sigma_condi=inv(Sigma_condi);
            [Sigma_cross_cov]=M_cross_cov(pts_target,pts_condi,nb_harddata,m);
        else
            CondiRadar_current=CondiRadar;
            for rr=1:length(CondiRadar_current)
                CondiRadar_current(rr).X=CondiRadar_current(rr).X-my_t*m(10)*cos(m(11)*pi/180);%project in Lagrangian reference frame
                CondiRadar_current(rr).Y=CondiRadar_current(rr).Y-my_t*m(10)*sin(m(11)*pi/180);%project in Lagrangian reference frame
                CondiRadar_current(rr).t=my_t;
                CondiRadar_current(rr).RainRate=CondiRadar(rr).RainRate(ind_radar);
            end
        end
    else
        %covariance matrix
        [Sigma_target]=M_cov_target(pts_target,m);
        
    end
    
    %----
    M_Z_Condi=[];
    for sim=1:nb_simul
        if Path_to_sim(i)>4 %avoid simulating noise at the begining
            if ind_sort>0
                Z_condi=[];
                for j=1:length(V_ind_cond)
                    for k=1:length(Coord_Euler(:,1))
                        Z_condi=[Z_condi; M_res_sim(k,Simulated_pts(V_ind_cond(j)),sim)];
                    end
                end
                for j=1:length(CondiRainTS_gaussian)
                    
                    my_idx=find((CondiRainTS_gaussian(j).t > (Path_to_sim(i)-10)*step_t) & (CondiRainTS_gaussian(j).t < (Path_to_sim(i)+10)*step_t));
                    ind_min=min(my_idx);
                    ind_max=max(my_idx);
                    
                    Z_condi=[Z_condi; CondiRainTS_gaussian(j).RainRate(ind_min:ind_max)];
                    
                end
            else
                Z_condi=[];
                for j=1:length(CondiRainTS_gaussian)
                    my_idx=find((CondiRainTS_gaussian(j).t > (Path_to_sim(i)-10)*step_t) & (CondiRainTS_gaussian(j).t < (Path_to_sim(i)+10)*step_t));
                    ind_min=min(my_idx);
                    ind_max=max(my_idx);
                    Z_condi=[Z_condi; CondiRainTS_gaussian(j).RainRate(ind_min:ind_max)];
                end
            end
            
            Z_target=[];
            if ~isempty(pts_condi)
                my_t=timeline_RainTS(Path_to_sim(i));
                ind_radar=find(abs(CondiRadar(1).t-my_t)<5);
                if isempty(ind_radar)
                    
                    if sim==1
                        Sigma_LU=Sigma_target-Sigma_cross_cov'*inv_Sigma_condi*Sigma_cross_cov;
                        L=chol(Sigma_LU,'lower');
                    end
                    mu=Sigma_cross_cov'*inv_Sigma_condi*Z_condi;
                    V_IID=randn(length(Sigma_target(:,1)),1);
                    Z_target=mu+L*V_IID;
                    
                else
                    M_Z_Condi=[M_Z_Condi Z_condi];
                end
                
            else
                Z_condi=0;
                Sigma_cross_cov=0;
                inv_Sigma_condi=0;
                
                if sim==1
                    Sigma_LU=Sigma_target-Sigma_cross_cov'*inv_Sigma_condi*Sigma_cross_cov;
                    L=chol(Sigma_LU,'lower');
                end
                mu=Sigma_cross_cov'*inv_Sigma_condi*Z_condi;
                V_IID=randn(length(Sigma_target(:,1)),1);
                Z_target=mu+L*V_IID;
            end
            
            if ~isempty(Z_target)
                for k=1:length(Coord_Euler(:,1))
                    M_res_sim(k,Path_to_sim(i),sim)=Z_target(k);
                end
            end
        end
    end
    if ~isempty(M_Z_Condi)
        [M_Z_target]=Merge_pluvi_radar(pts_target,pts_condi,M_Z_Condi,CondiRadar_current,m,pts_per_km,nb_iter_gibbs);
        for sim=1:nb_simul
            for k=1:length(Coord_Euler(:,1))
                M_res_sim(k,Path_to_sim(i),sim)=M_Z_target(k,sim);
            end
        end
    end
    
    Simulated_pts=[Simulated_pts; Path_to_sim(i)];
end

%create final structure
M_SimulatedRainTS=[];
for sim=1:nb_simul
    SimulatedRainTS=struct();
    for i=1:length(Coord_Euler(:,1))
        SimulatedRainTS(i).X=Coord_Euler(i,1);
        SimulatedRainTS(i).Y=Coord_Euler(i,2);
        SimulatedRainTS(i).t=zeros(length(Path_to_sim),1);
        SimulatedRainTS(i).RainRate=zeros(length(Path_to_sim),1);
        for j=1:nb_ep
            SimulatedRainTS(i).t(j)=j*step_t;
            if M_res_sim(i,j,sim)>m(7)
                SimulatedRainTS(i).RainRate(j)=m(9)*(exp(m(8)*((M_res_sim(i,j,sim)-m(7))^m(12)))-1);
            else
                SimulatedRainTS(i).RainRate(j)=0;
            end
        end
    end
    M_SimulatedRainTS=[M_SimulatedRainTS;SimulatedRainTS];
end

%------subfunctions-------

function[Sigma_target]=M_cov_target(pts_target,m)

    V_X=pts_target(:,1);
    V_Y=pts_target(:,2);
    V_t=pts_target(:,3);

    MVX1=repmat(V_X,1,length(V_X));
    MVX2=repmat(V_X',length(V_X),1);
    clear V_X
    MVY1=repmat(V_Y,1,length(V_Y));
    MVY2=repmat(V_Y',length(V_Y),1);
    clear V_Y
    
    M_ds=sqrt((MVX2-MVX1).^2+(MVY2-MVY1).^2);
    clear MVX1
    clear MVX2
    clear MVY1
    clear MVY2
    
    MVt1=repmat(V_t,1,length(V_t));
    MVt2=repmat(V_t',length(V_t),1);
    clear V_t

    M_dt=abs(MVt2-MVt1);
    clear MVt1
    clear MVt2

    to=1;
    c=m(1)^(-2*m(2));
    a=m(3)^(-2*m(4));
    Elem=a.*M_dt.^(2*m(4))+1;
    Sigma=1./(Elem.^to).*exp(-c.*(M_ds.^(2.*m(2)))./(Elem.^(m(5).*m(2))));
    
    Sigma_target=(1-m(6)^2)*Sigma; %no measurement noise between target points
end

function[Sigma_obs]=M_cov_obs(pts_obs,nb_harddata,m)

    V_X=pts_obs(:,1);
    V_Y=pts_obs(:,2);
    V_t=pts_obs(:,3);

    MVX1=repmat(V_X,1,length(V_X));
    MVX2=repmat(V_X',length(V_X),1);
    clear V_X
    MVY1=repmat(V_Y,1,length(V_Y));
    MVY2=repmat(V_Y',length(V_Y),1);
    clear V_Y
    
    M_ds=sqrt((MVX2-MVX1).^2+(MVY2-MVY1).^2);
    clear MVX1
    clear MVX2
    clear MVY1
    clear MVY2
    
    MVt1=repmat(V_t,1,length(V_t));
    MVt2=repmat(V_t',length(V_t),1);
    clear V_t

    M_dt=abs(MVt2-MVt1);
    clear MVt1
    clear MVt2

    to=1;
    c=m(1)^(-2*m(2));
    a=m(3)^(-2*m(4));
    Elem=a.*M_dt.^(2*m(4))+1;
    Sigma=1./(Elem.^to).*exp(-c.*(M_ds.^(2.*m(2)))./(Elem.^(m(5).*m(2))));
        
    %measurement noise only for hard data (and not internal conditioning)
    [si,~]=size(M_ds);
    Sigma_obs=(1-m(6)^2)*Sigma;
    M_noise=[[zeros(si-nb_harddata,si-nb_harddata) zeros(si-nb_harddata,nb_harddata)];[zeros(nb_harddata,si-nb_harddata) eye(nb_harddata)*(m(6)^2)]];
    Sigma_obs=Sigma_obs+M_noise;
end

function[Sigma_cross]=M_cross_cov(pts_target,pts_obs,nb_harddata,m)

    V_X_t=pts_target(:,1);
    V_Y_t=pts_target(:,2);
    V_X_o=pts_obs(:,1);
    V_Y_o=pts_obs(:,2);

    MVX1=repmat(V_X_t',length(V_X_o),1);
    MVY1=repmat(V_Y_t',length(V_Y_o),1);
    MVX2=repmat(V_X_o,1,length(V_X_t));
    MVY2=repmat(V_Y_o,1,length(V_Y_t));
    clear V_X_t;
    clear V_Y_t;
    clear V_X_o;
    clear V_Y_o;


    M_ds=sqrt((MVX2-MVX1).^2+(MVY2-MVY1).^2);
    clear MVX1;
    clear MVY1;
    clear MVX2;
    clear MVY2;

    V_time_t=pts_target(:,3);
    V_time_o=pts_obs(:,3);

    MVt1=repmat(V_time_t',length(V_time_o),1);
    MVt2=repmat(V_time_o,1,length(V_time_t));
    clear V_time_t;
    clear V_time_o;

    M_dt=abs(MVt2-MVt1);
    clear MVt1;
    clear MVt2;

    to=1;
    c=m(1)^(-2*m(2));
    a=m(3)^(-2*m(4));
    Elem=a.*M_dt.^(2*m(4))+1;
    Sigma_cross=1./(Elem.^to).*exp(-c.*(M_ds.^(2.*m(2)))./(Elem.^(m(5).*m(2))));
    Sigma_cross=(1-m(6)^2)*Sigma_cross;
    [si,~]=size(M_ds);
    
    M_noise=(M_ds==0).*(M_dt==0).*[ones(si-nb_harddata,length(pts_target(:,1)))*(m(6)^2); zeros(nb_harddata,length(pts_target(:,1)))];
    Sigma_cross=Sigma_cross+M_noise;
end

end