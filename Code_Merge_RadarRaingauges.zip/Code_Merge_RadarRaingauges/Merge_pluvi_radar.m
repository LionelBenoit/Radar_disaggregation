function[Z_target]=Merge_pluvi_radar(pts_target,pts_condi,Z_condi,MeasuredRadar,m,pts_per_km,nb_iter_gibbs)
display('ping')
X_radar=[];
Y_radar=[];
for i=1:length(MeasuredRadar)
    X_radar=[X_radar; MeasuredRadar(i).X];
    Y_radar=[Y_radar; MeasuredRadar(i).Y];
end

Z_result=zeros(length(pts_target(:,1)),1);
pts_result=pts_target;

R_Data=zeros(length(Z_result),1);
R_Data_latent=zeros(length(Z_result),1);
V_corresp_radar=zeros(length(Z_result),1);

%prepare data
ind=0;

my_t=MeasuredRadar(1).t;

for i=1:length(pts_target)
    ind=ind+1;
    
    V_dist_X=abs(pts_target(i,1)-X_radar);
    V_dist_Y=abs(pts_target(i,2)-Y_radar);
    ind1=find(V_dist_X<500);
    ind2=find(V_dist_Y(ind1)<500);
    ind_temp=ind1(ind2);
    V_corresp_radar(ind)=ind_temp(1);
    
    R_Data(ind)=MeasuredRadar(ind_temp(1)).RainRate(1);
    
    if R_Data(ind)<0.05
        Z_result(ind)=m(13)-0.1+randn*0.1;
        R_Data_latent(ind)=m(13)-0.1+randn*0.1;
    else
        Z_result(ind)=m(14)*(R_Data(ind)^m(15))+m(13);
        R_Data_latent(ind)=m(14)*(R_Data(ind)^m(15))+m(13);
        
    end
    
end



Struct_related_gridpoints=struct();
Struct_L_values=struct();
K_values=zeros(length(Z_result),1);

m_krig=m(1:11);
m_krig(6)=0;
Lambda_a=[];
Var_est=[];
for i=1:length(Z_result)
    ind1=find(V_corresp_radar==V_corresp_radar(i));
    my_t=pts_result(i,3);
    ind2=find(pts_result(ind1,3)==my_t);
    V_ind=ind1(ind2);
    Struct_related_gridpoints(i).V_ind=V_ind;
    
    if isempty(Lambda_a) %constant geometry within radar pixels
        [Lambda_a,~,Var_est]=Block_Kriging(pts_result(V_ind,1),pts_result(V_ind,2),Z_result(V_ind),MeasuredRadar(V_corresp_radar(i)).X-500-my_t*m(10)*cos(m(11)*pi/180),100,MeasuredRadar(V_corresp_radar(i)).X+500-my_t*m(10)*cos(m(11)*pi/180),MeasuredRadar(V_corresp_radar(i)).Y-500-my_t*m(10)*sin(m(11)*pi/180),100,MeasuredRadar(V_corresp_radar(i)).Y+500-my_t*m(10)*sin(m(11)*pi/180),m_krig);
    end
    
    K_values(i)=sqrt(Var_est);
    Struct_L_values(i).Lambda=Lambda_a; 
end

my_Z_result=Z_result;

%-------------------------gibbs sampling to simulate censored values--------------------------

%Compute covariance matrix of point process - Cz
V_X=[pts_condi(:,1);pts_result(:,1)];
V_Y=[pts_condi(:,2);pts_result(:,2)];
V_t=[pts_condi(:,3);pts_result(:,3)];

MVX1=repmat(V_X,1,length(V_X));
MVX2=repmat(V_X',length(V_X),1);
clear V_X
MVY1=repmat(V_Y,1,length(V_Y));
MVY2=repmat(V_Y',length(V_Y),1);
clear V_Y
M_ds=sqrt((MVX2-MVX1).^2+(MVY2-MVY1).^2);
clear MVX1
clear MVX2
clear MVY1
clear MVY2
MVt1=repmat(V_t,1,length(V_t));
MVt2=repmat(V_t',length(V_t),1);
clear V_t
M_dt=abs(MVt2-MVt1);
clear MVt1
clear MVt2

to=1;
c=m(1)^(-2*m(2));
a=m(3)^(-2*m(4));
Elem=a.*M_dt.^(2*m(4))+1;
Cz=1./(Elem.^to).*exp(-c.*(M_ds.^(2.*m(2)))./(Elem.^(m(5).*m(2)))); %no measurement noise in simulations

%compute sampling matrix: G and data vector D
nb_condi=length(pts_condi(:,1));
G_condi=eye(nb_condi,nb_condi);
D_condi=Z_condi;

nb_blocks=length(MeasuredRadar);
G_block=zeros(nb_blocks,length(pts_target(:,1)));
D_block=zeros(nb_blocks,1);
ind_pix=unique(V_corresp_radar,'sorted');
V_inds_G_to_sample_gibbs=[];
for l=1:length(ind_pix)
    inds=find( (V_corresp_radar==ind_pix(l)));
    G_block(l,inds)=1/(pts_per_km^2);
    if R_Data(inds(1))<0.05
        V_inds_G_to_sample_gibbs=[V_inds_G_to_sample_gibbs; nb_condi+l];
        D_block(l)=m(13)-0.1+randn*0.1;
    else
        
        my_rain=R_Data(inds(1));
        D_block(l)=m(14)*(my_rain^m(15))+m(13);
    end
end

[sx1,sy1]=size(G_condi);
[sx2,sy2]=size(G_block);
G=[[G_condi zeros(sx1,sy2)];[zeros(sx2,sy1) G_block]];
D=[D_condi;D_block];


%Compute covariance matrix of the data vector: Cd
Cd=G*Cz*G';
inv_Cd=inv(Cd);

%Gibbs sampling of censored latent values (aggregated)
if ~isempty(V_inds_G_to_sample_gibbs) && m(8)*m(9)~=1
    
    for iter=1:nb_iter_gibbs
        
        for i=1:length(V_inds_G_to_sample_gibbs)
            
            [ mu_gibbs, sigma_gibbs ] = conditional_normal_sim(inv_Cd,V_inds_G_to_sample_gibbs(i),D);
            sim_value=mu_gibbs+randn*sigma_gibbs;
            it=0;
            
            while sim_value > m(13) && it <100
                sim_value=mu_gibbs+randn*sigma_gibbs;
                it=it+1;
            end
            D(V_inds_G_to_sample_gibbs(i))=sim_value;
            
        end
    end
    
end


%Disaggregate radar pixels => LU factorization

Cz_pt=Cz(nb_condi+1:end,nb_condi+1:end);
Czd=Cz*G';
Czd_pt=Czd(nb_condi+1:end,:)*(1-0.01^2);
Cdz_pt=Czd_pt';
C_LU=Cz_pt-Czd_pt*inv_Cd*Cdz_pt;
mu_LU=Czd_pt*inv_Cd*D;

L=chol(C_LU,'lower');
V_IID=randn(length(C_LU(:,1)),1);
Z_target=mu_LU+L*V_IID;

end