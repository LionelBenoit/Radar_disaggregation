close all
clear all

%--------------------PARAMETERS - To change according to the applications-------------
%Meta_parameters
nb_simul=2;
pts_per_km=5;

%parameters of simulation grid
E_min=572834-2000;
N_min=117843-2000;
E_max=574480+2000;
N_max=120705+2000;
Footprint_area=[E_min;E_max;N_min;N_max];

%parameters of radar data
E_min_rad=572834-10000;
N_min_rad=117843-10000;
E_max_rad=574480+10000;
N_max_rad=120705+10000;
step_sec=10*60;

%parameters for rain movie
output_file='Gif_test.gif'; %name output file for movie (format .gif).
gif_fps=5; %number of frames per second
my_colormax=50; %max intensity for colorbar (mm/h).

%%
%-------------------LOAD DATA--------------------
M_Simul_mergedata=[];
folder_data='Test_dataset'; %dataset to process - to be changed to select another dataset 
cd(folder_data)
M=load('MeasuredRainTS_test.mat');
MeasuredRainTS=M.MeasuredRainTS;

for i=1:length(MeasuredRainTS)
    MeasuredRainTS(i).t=MeasuredRainTS(i).t(6:end); %5 for Test_dataset, 6 for Test_dataset_2 and Test_dataset_3
    MeasuredRainTS(i).RainRate=MeasuredRainTS(i).RainRate(6:end);
end

t0=MeasuredRainTS(1).t(1);
for i=1:length(MeasuredRainTS)
    for j=1:length(MeasuredRainTS(i).t)
        MeasuredRainTS(i).t_double(j)=etime(datevec(MeasuredRainTS(i).t(j)),datevec(t0));
    end
    MeasuredRainTS(i).t_datetime=MeasuredRainTS(i).t;
    MeasuredRainTS(i).t=(MeasuredRainTS(i).t_double)';
    MeasuredRainTS(i).t_double=[];
end
cd('..')


Footprint_area_rad=[E_min_rad;E_max_rad;N_min_rad;N_max_rad];
[MeasuredRadar]=read_raw_radar(Footprint_area_rad,MeasuredRainTS(1).t_datetime,step_sec,folder_data);
[ShiftedRadar,shift_X,shift_Y,T_results]=compute_radar_shift(MeasuredRadar,MeasuredRainTS,1000,8000);

MeasuredRadar=struct();
ind=1;
for i=1:length(ShiftedRadar)
    if ShiftedRadar(i).X>E_min && ShiftedRadar(i).X<E_max && ShiftedRadar(i).Y>N_min && ShiftedRadar(i).Y<N_max
        MeasuredRadar(ind).X=ShiftedRadar(i).X;
        MeasuredRadar(ind).Y=ShiftedRadar(i).Y;
        MeasuredRadar(ind).t=ShiftedRadar(i).t;
        MeasuredRadar(ind).RainRate=ShiftedRadar(i).RainRate;
        ind=ind+1;
    end
end

figure(1)
clf
hold on
for i=1:length(MeasuredRainTS)
    plot(MeasuredRainTS(i).t,MeasuredRainTS(i).RainRate,'k')
end

for i=1:length(MeasuredRadar)
    plot(MeasuredRadar(i).t,MeasuredRadar(i).RainRate,'g')
end


%%
%-----------------CALIBRATE STOCHASTIC MODEL------------------
%Calibration for rain gauges
[m0,V_step_walk,M_prior]=set_Metropolis_hastings(MeasuredRainTS);
nb_ep_warmup=2000;
nb_sample=nb_simul;
step=50;
%likelihood parameters
size_block=10; %composite likelihood - block size in epochs
nb_iter_Gibbs=10; %gibbs sampler for censored values
%--end parameters to set----------
%run Metropolis sampler
[V_tot_raingauges, V_sample_raingauges]=Metropolis_block_likelihood_gibbs(m0,V_step_walk,M_prior,MeasuredRainTS,size_block,nb_ep_warmup,nb_sample,step, nb_iter_Gibbs);
%plot results
plot_result_metropolis3( V_tot_raingauges, 2 )
m_raingauges=mean(V_sample_raingauges(:,1:11));

V_raingauge_data=[];
for i=1:length(MeasuredRainTS)
    V_raingauge_data=[V_raingauge_data;MeasuredRainTS(i).RainRate];
end

V_q_Raingauges=[];
V_q_Latent_raingauges=[];

for my_q=1:1000
    my_quantile_raingauge=quantile(V_raingauge_data,my_q/1000);
    V_q_Raingauges=[V_q_Raingauges;my_quantile_raingauge];
    my_quantile_latent=norminv(my_q/1000);
    V_q_Latent_raingauges=[V_q_Latent_raingauges;my_quantile_latent];
end

figure(3)
clf
hold on
for i=1:nb_sample
    my_V=0.01:0.5:max(V_raingauge_data)+5;
    my_V_lat=V_sample_raingauges(i,8).*( my_V.^V_sample_raingauges(i,9))+V_sample_raingauges(i,7);
    plot(my_V,my_V_lat,'k')
end
plot(V_q_Raingauges,V_q_Latent_raingauges,'r+')


%Calibration for radar
MeasuredRadar_calib=MeasuredRadar(5:end);
for i=1:length(MeasuredRadar_calib)
    for j=1:length(MeasuredRadar_calib(i).RainRate)
        if MeasuredRadar_calib(i).RainRate(j)>0.05
            MeasuredRadar_calib(i).RainRate(j)=max(MeasuredRadar_calib(i).RainRate(j)+randn*0.3,0.01);
        end
    end
end

[m0,V_step_walk,M_prior]=set_Metropolis_hastings(MeasuredRadar_calib);

nb_ep_warmup=2000;
nb_sample=nb_simul;
step=50;
%likelihood parameters
size_block=10; %composite likelihood - block size in epochs
nb_iter_Gibbs=10; %gibbs sampler for censored values
%--end parameters to set----------
%run Metropolis sampler
[V_tot_radar, V_sample_radar]=Metropolis_block_likelihood_gibbs(m0,V_step_walk,M_prior,MeasuredRadar_calib,size_block,nb_ep_warmup,nb_sample,step, nb_iter_Gibbs);
%plot results
plot_result_metropolis3( V_tot_radar, 4 )
m_radar=mean(V_sample_radar(:,1:11));


V_radar_data=[];
for i=1:length(MeasuredRadar_calib)
    V_radar_data=[V_radar_data;MeasuredRadar_calib(i).RainRate];
end

V_q_Radar=[];
V_q_Latent_radar=[];

for my_q=1:1000
    my_quantile_radar=quantile(V_radar_data,my_q/1000);
    V_q_Radar=[V_q_Radar;my_quantile_radar];
    my_quantile_latent=norminv(my_q/1000);
    V_q_Latent_radar=[V_q_Latent_radar;my_quantile_latent];
end

figure(5)
clf
hold on
for i=1:nb_sample
    my_V=0.01:0.5:max(V_radar_data)+5;
    my_V_lat=V_sample_radar(i,8).*( my_V.^V_sample_radar(i,9))+V_sample_radar(i,7);
    plot(my_V,my_V_lat,'k')
end
plot(V_q_Radar,V_q_Latent_radar,'r+')

%%
%-----------------------DATA FUSION--------------------------------------


X_radar=[];
Y_radar=[];
for i=1:length(MeasuredRadar)
    X_radar=[X_radar; MeasuredRadar(i).X];
    Y_radar=[Y_radar; MeasuredRadar(i).Y];
end
min_X_grid=min(X_radar)-500+0.5*1000/pts_per_km;
max_X_grid=max(X_radar)+500-0.5*1000/pts_per_km;
min_Y_grid=min(Y_radar)-500+0.5*1000/pts_per_km;
max_Y_grid=max(Y_radar)+500-0.5*1000/pts_per_km;


X_grid=min_X_grid:1000/pts_per_km:max_X_grid;
Y_grid=min_Y_grid:1000/pts_per_km:max_Y_grid;

Coord_Euler=[];
for i=1:length(X_grid)
    for j=1:length(Y_grid)
        Coord_Euler=[Coord_Euler;[X_grid(i),Y_grid(j)]];
    end
end

Condi_RainTS_gaussian=MeasuredRainTS;
for i=1:length(Condi_RainTS_gaussian)

    for j=1:length(Condi_RainTS_gaussian(i).t)-10
        if Condi_RainTS_gaussian(i).RainRate(j)<0.01
            Condi_RainTS_gaussian(i).RainRate(j)=V_sample_raingauges(1,11+(j-1)*length(Condi_RainTS_gaussian)+i);
        else
            Condi_RainTS_gaussian(i).RainRate(j)=m_raingauges(8)*(Condi_RainTS_gaussian(i).RainRate(j)^m_raingauges(9))+m_raingauges(7);
        end
    end
    
    Condi_RainTS_gaussian(i).t=Condi_RainTS_gaussian(i).t(2:end);
    Condi_RainTS_gaussian(i).RainRate=Condi_RainTS_gaussian(i).RainRate(2:end);
end

CondiRadar=MeasuredRadar;

step_t=Condi_RainTS_gaussian(1).t(2)-Condi_RainTS_gaussian(1).t(1);
nb_max_cond=2;

nb_ep=length(Condi_RainTS_gaussian(1).t);

M_SimulatedRainTS=[];
m=[m_raingauges, 0, m_radar(7:9)];
nb_iter_gibbs=50;
for ind_sim=1:nb_simul
    [SimulatedRainTS]=simul_condi_multigrid_withradar(Coord_Euler,pts_per_km,Condi_RainTS_gaussian,CondiRadar,m,nb_ep, step_t,nb_max_cond,nb_iter_gibbs);
    M_SimulatedRainTS=[M_SimulatedRainTS;SimulatedRainTS];
end

%%
%------------------------GENERATE MOVIE RESULTS----------------------
Make_movie_simulations(M_SimulatedRainTS,nb_simul,MeasuredRainTS,CondiRadar,X_grid,Y_grid,E_min,E_max,N_min,N_max,pts_per_km,output_file,gif_fps,my_colormax)