function[MeasuredRadar]=read_raw_radar(Footprint_area,time_line,step_sec,folder_data)

%----------------load radar data------------

cd(folder_data)
cd('Radar_images')

[Y_ini,M_ini,D_ini,H_ini,MN_ini,S_ini] = datevec(time_line(1));

d0=strcat('01/01/',num2str(Y_ini));
d0=datenum(d0);

doy_ini=datenum(strcat(num2str(M_ini),'/',num2str(D_ini),'/',num2str(Y_ini)));
doy_ini=doy_ini-d0+1;

[Y_end,M_end,D_end,H_end,MN_end,S_end] = datevec(time_line(end));
doy_end=datenum(strcat(num2str(M_end),'/',num2str(D_end),'/',num2str(Y_end)));
doy_end=doy_end-d0+1;

My_conv=load('my_table_covert.txt');

sec_ini0=Y_ini*365*86400+doy_ini*86400+H_ini*3600+MN_ini*60+S_ini;
sec_ini=ceil(sec_ini0/step_sec)*step_sec;
sec_end=Y_end*365*86400+doy_end*86400+H_end*3600+MN_end*60+S_end;
sec_end=floor(sec_end/step_sec)*step_sec;


c_min=ceil((Footprint_area(1)-255000)/1000);
l_max=ceil((480000-Footprint_area(3))/1000);
c_max=ceil((Footprint_area(2)-255000)/1000);
l_min=ceil((480000-Footprint_area(4))/1000);

MeasuredRadar=struct();
cropped_data=zeros(length(l_min:l_max),length(c_min:c_max));
[nl,nc]=size(cropped_data);

ind=0;
for l=1:nl
    for c=1:nc
        ind=ind+1;
        MeasuredRadar(ind).X=255000+(c_min-1)*1000+500+(c-1)*1000; %coordinates of pixel center
        MeasuredRadar(ind).Y=480000-(l_min-1)*1000-(l-1)*1000-500; %coordinates of pixel center
        MeasuredRadar(ind).t=[];
        MeasuredRadar(ind).RainRate=[];
    end
end

for sec=sec_ini:step_sec:sec_end
    %change folder if needed
    doy_tp1=doy_from_sec(sec);
    
    [rain_data_matrix]=load_data(sec,My_conv); 
    

    cropped_data=rain_data_matrix(l_min:l_max,c_min:c_max);
    [nl,nc]=size(cropped_data);
    ind=0;
    for l=1:nl
        for c=1:nc
            ind=ind+1;
            MeasuredRadar(ind).t=[MeasuredRadar(ind).t;sec-sec_ini0];
            MeasuredRadar(ind).RainRate=[MeasuredRadar(ind).RainRate;max(cropped_data(l,c),0)];
        end
    end
end

cd('..')
cd('..')

end


function[doy]=doy_from_sec(sec)
    doy=floor((sec-floor(sec/(365*86400))*365*86400)/86400);
end

function[rain_data_matrix]=load_data(sec,My_conv)
    str_year=num2str(floor(sec/(365*86400)));
    str_doy=num2str(floor((sec-str2double(str_year)*365*86400)/86400),'%03d');
    str_hour=num2str(floor((sec-str2double(str_year)*365*86400-str2double(str_doy)*86400)/3600),'%02d');
    str_min=num2str(floor((sec-str2double(str_year)*365*86400-str2double(str_doy)*86400-str2double(str_hour)*3600)/60),'%02d');
        
    str_dir=strcat('RZC',str_year(3:4),str_doy,str_hour,str_min,'**.801.gif');
    struct_file=dir(str_dir);
    display(strcat('Process year=',str_year,' doy=',str_doy,' hour=',str_hour,' min=',str_min))
    display(strcat('Open file : ',str_dir))
    if isempty(struct_file)==1
        rain_data_matrix=[];
        display(strcat('Cannot find radar file!!!'))
        return;
    else
        str_file=struct_file.name;
    end

    %[matrix, map] = geotiffread(str_file);
    [matrix, map] = imread(str_file);
    %convert data in mm/h
    [sx,sy]=size(matrix);
    rain_data_matrix=zeros(sx,sy);

    for i=1:sx
        for j=1:sy
            rain_data_matrix(i,j)=My_conv(matrix(i,j)+1,2); 
        end
    end
    
end