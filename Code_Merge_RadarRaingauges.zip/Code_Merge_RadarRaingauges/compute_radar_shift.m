function[ShiftedRadar,shift_X,shift_Y,T_results]=compute_radar_shift(MeasuredRadar,MeasuredRainTS,step,maxshift)

T_results=[];
for sx=-maxshift:step:maxshift
    for sy=-maxshift:step:maxshift
        
        TestedRadar=MeasuredRadar;
        my_X=[];
        my_Y=[];
        for i=1:length(MeasuredRadar)
            TestedRadar(i).X=TestedRadar(i).X+sx;
            my_X=[my_X;TestedRadar(i).X];
            TestedRadar(i).Y=TestedRadar(i).Y+sy;
            my_Y=[my_Y;TestedRadar(i).Y];
        end
        
        T_corresp=zeros(length(MeasuredRainTS),1);
        
        
        
        for i=1:length(MeasuredRainTS)
            dist=sqrt((MeasuredRainTS(i).X-my_X).^2+(MeasuredRainTS(i).Y-my_Y).^2);
            my_min=min(dist);
            my_min=my_min(1);
            ind=find(dist==my_min);
            ind=ind(1);
            T_corresp(i)=ind;
        end
        
        
        Data_raingauge=[];
        Data_radar=[];
        for i=1:length(T_corresp)
            for j=1:length(TestedRadar(T_corresp(i)).RainRate)
                Data_radar=[Data_radar;TestedRadar(T_corresp(i)).RainRate(j)];
                my_t=find(abs(MeasuredRainTS(i).t-TestedRadar(T_corresp(i)).t(j))<30);
                Data_raingauge=[Data_raingauge;MeasuredRainTS(i).RainRate(my_t)];
            end
        end
        
        my_corr=corr(Data_radar,Data_raingauge,'Type','Spearman');
        
        T_results=[T_results;[sx sy my_corr]];
        
    end
end

my_max=nanmax(T_results(:,3));
my_max=my_max(1);
ind=find(T_results(:,3)==my_max);
ind=ind(1);

shift_X=T_results(ind,1);
shift_Y=T_results(ind,2);

ShiftedRadar=MeasuredRadar;
for i=1:length(MeasuredRadar)
    ShiftedRadar(i).X=ShiftedRadar(i).X+shift_X;
    ShiftedRadar(i).Y=ShiftedRadar(i).Y+shift_Y;
end



end