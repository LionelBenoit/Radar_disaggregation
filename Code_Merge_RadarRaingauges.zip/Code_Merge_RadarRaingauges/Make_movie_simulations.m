function[]=Make_movie_simulations(M_SimulatedRainTS,nb_simul,MeasuredRainTS,CondiRadar,X_grid,Y_grid,E_min,E_max,N_min,N_max,pts_per_km,output_file,gif_fps,my_colormax)

SimulatedRainTS=M_SimulatedRainTS(1,:);

M_rainrates_final=NaN(nb_simul,length(SimulatedRainTS),length(SimulatedRainTS(1).RainRate));

for sim=1:nb_simul
    sim
    SimulatedRainTS_final=M_SimulatedRainTS(sim,:);
    for i=1:length(SimulatedRainTS)
        for j=1:length(SimulatedRainTS(i).RainRate)
            
            M_rainrates_final(sim,i,j)=SimulatedRainTS_final(i).RainRate(j);
            
            
        end
    end
end

SimulatedRainTS_median=SimulatedRainTS;
SimulatedRainTS_Q10=SimulatedRainTS;
SimulatedRainTS_Q90=SimulatedRainTS;

for i=1:length(SimulatedRainTS)
    i
    for j=1:length(SimulatedRainTS(i).RainRate)
        SimulatedRainTS_median(i).RainRate(j)=quantile(M_rainrates_final(:,i,j),0.5);
        SimulatedRainTS_Q10(i).RainRate(j)=quantile(M_rainrates_final(:,i,j),0.1);
        SimulatedRainTS_Q90(i).RainRate(j)=quantile(M_rainrates_final(:,i,j),0.9);
    end
end


V_t_radar=[];
for i=1:length(CondiRadar(1).t)
    V_t_radar=[V_t_radar;CondiRadar(1).t(i)];
end

V_t_gauges=[];
for i=1:length(MeasuredRainTS(1).t)
    V_t_gauges=[V_t_gauges;MeasuredRainTS(1).t(i)];
end


fig=figure('Renderer', 'painters', 'Position', [10 10 1800 600]);


for my_time=1:length(SimulatedRainTS_median(1).RainRate)-10
    
    ind_t_gauges=find(abs(V_t_gauges-SimulatedRainTS_median(1).t(my_time))<5);
    
    my_ind_time_radar=find(abs(V_t_radar-SimulatedRainTS_median(1).t(my_time))<=5*60);
    my_ind_time_radar=my_ind_time_radar(1);
    
    
    if ~isempty(my_ind_time_radar)
        my_img_rad=[];
        ind=1;
        for ny=1:7
            V_temp=[];
            for nx=1:5
                V_temp=[V_temp, CondiRadar(ind).RainRate(my_ind_time_radar)];
                ind=ind+1;
            end
            my_img_rad=[my_img_rad;V_temp];
        end
    else
        my_img_rad=zeros(7,6);
    end
    subplot(1,4,1)
    hold off
    imagesc(my_img_rad)
    title('Radar data (mm/h)')
    text(14,-1,datestr(datenum(MeasuredRainTS(1).t_datetime(ind_t_gauges))),'FontSize',14)
    hold on
    my_map=colormap('jet');
    my_map(1,:)=[1 1 1];
    colormap(my_map)
    caxis([0 my_colormax])
    colorbar
    axis equal tight
    
    %---
    subplot(1,4,2)
    my_img=zeros(length(Y_grid),length(X_grid));
    for i=1:length(MeasuredRainTS)
        ind_c=round((MeasuredRainTS(i).X-E_min)/(1000/pts_per_km));
        ind_l=1+round((N_max-MeasuredRainTS(i).Y)/(1000/pts_per_km));
        my_img(ind_l,ind_c)=MeasuredRainTS(i).RainRate(ind_t_gauges);
    end
    %my_img=flipud(my_img);
    imagesc(my_img)
    title('Rain gauge data (mm/h)')
    my_map=colormap('jet');
    my_map(1,:)=[1 1 1];
    colormap(my_map)
    caxis([0 my_colormax])
    colorbar
    axis equal tight
    
    %----
    
    my_time
    ind=1;
    my_img=[];
    my_img_uncertainty=[];
    for i=1:length(X_grid)
        V_temp=[];
        V_temp_uncertainty=[];
        for j=1:length(Y_grid)
            V_temp=[V_temp;SimulatedRainTS_median(ind).RainRate(my_time)];
            V_temp_uncertainty=[V_temp_uncertainty;SimulatedRainTS_Q90(ind).RainRate(my_time)-SimulatedRainTS_Q10(ind).RainRate(my_time)];
            ind=ind+1;
        end
        my_img=[my_img,V_temp];
        my_img_uncertainty=[my_img_uncertainty,V_temp_uncertainty];
    end
    
    subplot(1,4,3)
    imagesc(flipud(my_img))
    title('Estimated rain intensity (mm/h)')
    my_map=colormap('jet');
    my_map(1,:)=[1 1 1];
    colormap(my_map)
    caxis([0 my_colormax])
    colorbar
    axis equal tight
    
    subplot(1,4,4)
    imagesc(flipud(my_img_uncertainty));
    title('Uncertainty (mm/h)')
    my_map=colormap('jet');
    my_map(1,:)=[1 1 1];
    colormap(my_map)
    caxis([0 my_colormax])
    colorbar
    axis equal tight
    
    
    %w = waitforbuttonpress;
    drawnow;
    
    %capture the plot as an image
    frame = getframe(fig); 
    im = frame2im(frame); 
    [imind,cm] = rgb2ind(im,256); 
    
    % Write to the GIF File 
    if my_time == 1
        imwrite(imind,cm,output_file,'gif', 'Loopcount',inf); 
    else
        imwrite(imind,cm,output_file,'gif','WriteMode','append','DelayTime',1/gif_fps); 
    end 
   
    
end


end